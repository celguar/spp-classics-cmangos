# mangosbot-EngBags
EngBags mod to manage bot inventory

# Installation Guide
1. Clone this repo and place it into Interface/AddOns folder on your client
2. Rename the addon folder to "EngBags" in order to make it appear in the client

# User Guide
1. Select a bot. Make sure it remains selected.
2. Start trading with bot or whisper 'c' or 'items' command. 

The window will be opened showing all bot's inventory:
![Screenshot](screenshot.png)

When finished close the window or deselect the bot.
Note: the window content is static and does not change during trade. The only way to refresh the data is to close the inventory window and restart the trade.
