
achieverDB = {
	["achievements"] = {
		["nextById"] = {},
		["version"] = -1,
		["byCategory"] = {},
		["data"] = {},
		["previousById"] = {},
		["totalPoints"] = 0,
	},
		["criteria"] = {
			["version"] = -1,
			["data"] = {},
			["byAchievement"] = {},
		},
		["categories"] = {
			["byParent"] = {},
			["version"] = -1,
			["data"] = {},
		},
	}
